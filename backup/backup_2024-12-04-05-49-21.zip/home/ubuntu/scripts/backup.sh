#!/bin/bash


source_dir="/home/ubuntu/scripts"
destintion_dir="/home/ubuntu/backup"

timestamp="$(date '+%Y-%m-%d-%H-%M-%S')"

backup_dir="${destintion_dir}/backup_${timestamp}"

zip -r "${backup_dir}.zip" ${source_dir}

echo "====Backup completed successfully===="






