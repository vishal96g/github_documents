#!/bin/bash
#
echo "Install the package: $1"

sudo apt-get install $1 -y
