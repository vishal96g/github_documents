#!/bin/bash
#
<< comment

This script will 
monitor the status
process status/process id
comment

read -p  "What you want to know of your service $1: (status/pid): " choice

if [[ $choice == "status" ]]
then 
	sudo systemctl status $1

elif [[ $choice == "pid" ]]
then 
	echo "Process id of $1 is: $(pgrep $1)"

else
        echo "Wrong input"
fi	



