#!/bin/bash
#
#
<< comment
This is the demo
of if else condition
in shell script
comment

# This is the demo of if else condition in shell script
#
read -p "Is it raining:  (Yes/No): " choice

if [[ $choice == "Yes" || $choice == "yes" || $choice == "Y" || $choice == "y" ]]
then 
	echo "Take an umbrella"

elif [[ $choice == "No" || $choice == "no" || $choice == "N" || $choice == "n" ]]
then
	echo "No need of ubmbrella"

else 
	echo "choice Yes or No"
fi

