#!/bin/bash

echo "==========CREATE USER ID AND SET PASSWORD=========="


read -p "Enter the username: " username
read -s -p "Enter the password: " password


#This will create a user id
sudo useradd -m $username

#This will set the password
echo -e "$password\n$password" | sudo passwd $username


echo "=========USER CREATED SUCCESSFULLY=========="
